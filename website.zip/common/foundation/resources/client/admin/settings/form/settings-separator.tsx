export function SettingsSeparator() {
  return <div className="bg-divider-lighter my-30 h-1" />;
}
