export interface ErrorLogItem {
  id: number;
  index: number;
  level: string;
  datetime: string;
  message: string;
  exception: string;
}
