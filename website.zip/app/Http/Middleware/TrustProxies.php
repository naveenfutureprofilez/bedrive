<?php

namespace App\Http\Middleware;

use Common\Core\Middleware\TrustProxies as Middleware;
use Illuminate\Http\Request;

class TrustProxies extends Middleware
{
  //
}
